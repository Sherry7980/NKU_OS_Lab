// user/dirtycow_test.c
#include <stdio.h>
#include <ulib.h>
#include <string.h>

int main(void) {
    cprintf("DirtyCOW vulnerability test\n");
    
    // 使用静态数组代替动态分配
    static char data[4096];
    
    // 初始化数据
    const char *original = "ORIGINAL DATA";
    for (int i = 0; original[i] != '\0'; i++) {
        data[i] = original[i];
    }
    data[13] = '\0';  // 确保字符串结束
    
    int pid = fork();
    if (pid == 0) {
        // 子进程尝试并发写入
        for (int i = 0; i < 100; i++) {
            data[0] = 'M';  // 触发COW
        }
        
        // 检查是否修改成功
        if (data[0] == 'M') {
            cprintf("Child: data modified (expected behavior)\n");
        }
        
        exit(0);
    } else if (pid > 0) {
        int exit_code = 0;
        waitpid(pid, &exit_code);
        
        // 父进程检查数据
        int is_original = 1;
        for (int i = 0; original[i] != '\0'; i++) {
            if (data[i] != original[i]) {
                is_original = 0;
                break;
            }
        }
        
        if (is_original) {
            cprintf("Test completed - no corruption should occur\n");
        } else {
            cprintf("ERROR: parent data corrupted!\n");
        }
    } else {
        cprintf("fork failed\n");
        return -1;
    }
    
    return 0;
}