// user/cowtest.c
#include <stdio.h>
#include <ulib.h>

#define TEST_SIZE 10

int main(void) {
    cprintf("COW Test Starting...\n");
    
    static int data[TEST_SIZE];
    
    for (int i = 0; i < TEST_SIZE; i++) {
        data[i] = i * 100;
    }
    cprintf("Parent: initialized data\n");
    
    int pid = fork();
    
    if (pid == 0) {
        // 子进程: 只读操作
        cprintf("Child: reading parent's data...\n");
        int sum = 0;
        for (int i = 0; i < TEST_SIZE; i++) {
            sum += data[i];
        }
        cprintf("Child: sum before write = %d\n", sum);
        
        if (sum != 4500) {
            cprintf("Child: ERROR - sum should be 4500\n");
            exit(-1);
        }
        
        // 写入操作 - 触发COW
        cprintf("Child: writing data (trigger COW)...\n");
        for (int i = 0; i < TEST_SIZE; i++) {
            data[i] = i * 200;
        }
        
        // 再次读取
        sum = 0;
        for (int i = 0; i < TEST_SIZE; i++) {
            sum += data[i];
        }
        cprintf("Child: sum after write = %d\n", sum);
        
        if (sum != 9000) {
            cprintf("Child: ERROR - sum should be 9000\n");
            exit(-2);
        }
        
        exit(0);
    } else if (pid > 0) {
        int exit_code = 0;
        waitpid(pid, &exit_code);
        
        if (exit_code == 0) {
            cprintf("Child completed successfully\n");
        } else {
            cprintf("Child failed with code %d\n", exit_code);
        }
        
        cprintf("Parent: checking data after child...\n");
        int sum = 0;
        for (int i = 0; i < TEST_SIZE; i++) {
            sum += data[i];
        }
        cprintf("Parent: sum = %d (should be 4500)\n", sum);
        
        if (sum == 4500 && exit_code == 0) {
            cprintf("COW Test PASSED!\n");
        } else {
            cprintf("COW Test FAILED!\n");
        }
    } else {
        cprintf("fork failed\n");
        return -1;
    }
    
    return 0;
}